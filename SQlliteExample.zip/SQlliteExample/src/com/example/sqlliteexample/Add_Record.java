package com.example.sqlliteexample;

import com.example.sqlliteexample.Add_Record;
import com.example.sqlliteexample.R;

import android.app.Activity;
import android.os.Bundle;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Add_Record extends Activity {

	DBhelper db;
	EditText name, phone;
	Button btn_submit,btn_Reset;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_record);

		name = (EditText) findViewById(R.id.editAddName);
		phone = (EditText) findViewById(R.id.editAddNumber);
		btn_submit = (Button) findViewById(R.id.submit);
		btn_Reset = (Button) findViewById(R.id.btnReset);
		db = new DBhelper(this);
		
		btn_submit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				String getName = name.getText().toString();
				String getPhone = phone.getText().toString();
				db.insertData(getName, getPhone);
				Toast.makeText(Add_Record.this, "Record inserted...",
						Toast.LENGTH_SHORT).show();

			}

		});

	
	btn_Reset.setOnClickListener(new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			clear();
			
		}

	});

}
	public void clear()
	{
		if(name!=null)
		{
			name.setText("");
		}
		if(phone!=null)
		{
			phone.setText("");
		}
	}

}
