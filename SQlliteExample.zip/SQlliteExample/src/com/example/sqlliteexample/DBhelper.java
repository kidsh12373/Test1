package com.example.sqlliteexample;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class DBhelper extends SQLiteOpenHelper{

	public static final  String DATABSE_NAME="DIR.db"; 
	public static final  String TABLE_CONTACTS="contacts";
	public static final String CONTACTS_ID = "id";
	public static final  String CONTACT_NAME="name";
	public static final  String CONTACT_PHONE="phone";
	
	public DBhelper(Context context) {
		super(context, DATABSE_NAME, null, 1);
		
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		db.execSQL("create table if not exists contacts "
				+ "(id integer primary key, name text,phone text)");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
	
		db.execSQL("DROP TABLE IF EXISTS contacts");
		onCreate(db);
	}
	public Cursor getAllContacts() 
	{
		ArrayList array_list = new ArrayList();
		// hp = new HashMap();
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor res = db.rawQuery("select * from contacts", null);
		return res;

	}
	public Cursor searchContacts(String name) {
		SQLiteDatabase db = this.getWritableDatabase();

		/*ContentValues values = new ContentValues();
		values.put("name", name);*/

		Cursor cursor = db.rawQuery("Select * from contacts where name='"+name+"'",null);

		return cursor;

	}
	public boolean insertData(String name,String phone)
	{
		SQLiteDatabase db=this.getWritableDatabase();
		ContentValues cv=new ContentValues();
		
		cv.put("name",name);
		cv.put("phone",phone);
		db.insert("contacts", null, cv);
		return true;
	}
	
	public void deleteContact(String name)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		db.delete(TABLE_CONTACTS, "name=?", new String[] { name });
	}
	
	public void updateContact(String name,String phone)
	{
		SQLiteDatabase db=this.getWritableDatabase();
		ContentValues cv=new ContentValues();
		 cv.put("name",name);
		 cv.put("phone",phone);
		 
		 db.update(TABLE_CONTACTS, cv, "name=?",
					new String[] { name });
		
	}
	public List<String> getAllLabels() {
		List<String> list = new ArrayList<String>();

		String selectQuery = "SELECT  * FROM " + TABLE_CONTACTS;

		SQLiteDatabase db = this.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);// selectQuery,selectedArguments

		if (cursor.moveToFirst()) {
			do {
				list.add(cursor.getString(1));// adding 2nd column data
			} while (cursor.moveToNext());
		}

		cursor.close();
		db.close();

		return list;
	}

	
	public Cursor getAllCotacts() 
	{
		ArrayList array_list = new ArrayList();
		// hp = new HashMap();
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor res = db.rawQuery("select * from contacts", null);
		return res;

	}
	
	

	

}
