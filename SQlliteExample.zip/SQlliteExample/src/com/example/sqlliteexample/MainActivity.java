package com.example.sqlliteexample;

import com.example.sqlliteexample.Display_Record;
import com.example.sqlliteexample.Delete_Record;
import com.example.sqlliteexample.Update_Record;
import com.example.sqlliteexample.Add_Record;
import com.example.sqlliteexample.MainActivity;
import com.example.sqlliteexample.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {

	Button add,delete,update,display;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		add = (Button) findViewById(R.id.btnAdd);
		update = (Button) findViewById(R.id.btnUpdate);
		delete = (Button) findViewById(R.id.btnDelete);
		display = (Button) findViewById(R.id.btnDisplay);

		add.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				Intent i = new Intent(MainActivity.this, Add_Record.class);
				startActivity(i);

			}
		});
		
		delete.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				Intent i = new Intent(getApplicationContext(),
						Delete_Record.class);
				startActivity(i);

			}
		});

		update.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				Intent i = new Intent(getApplicationContext(),
						Update_Record.class);
				startActivity(i);

			}
		});
		
		display.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				Intent i = new Intent(getApplicationContext(),
						Display_Record.class);
				startActivity(i);

			}
		});
	}
}
